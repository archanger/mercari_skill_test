## My scenario choice is B

I've spent as much time as I thought necessary on this task. And additional tasks were beyond this time. In my opinion, I've made flexible and scalable solution.

## What I didn't:

* Localization
* Pretty smooth image loading (in background thread)
* Pagination
* Tests
* Other additional features